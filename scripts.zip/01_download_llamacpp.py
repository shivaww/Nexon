#!/usr/bin/env python3
"""
Download precompiled llama.cpp (CUDA) for Kaggle dual T4 GPUs
Source: https://github.com/ai-dock/llama.cpp-cuda
"""

import os
import sys
import tarfile
import urllib.request
from pathlib import Path

# Latest release (as of Aug 2026) - update tag if needed
VERSION = "b10472"
CUDA_VER = "12.8"
ARCH = "amd64"          # Kaggle is x86_64

FILENAME = f"llama.cpp-{VERSION}-cuda-{CUDA_VER}-{ARCH}.tar.gz"
URL = f"https://github.com/ai-dock/llama.cpp-cuda/releases/download/{VERSION}/{FILENAME}"

# Where to put it on Kaggle
DEST_DIR = Path("/kaggle/working/llama.cpp")
ARCHIVE_PATH = DEST_DIR / FILENAME

def download_with_progress(url: str, dest: Path):
    print(f"Downloading: {url}")
    print(f"Saving to  : {dest}")

    dest.parent.mkdir(parents=True, exist_ok=True)

    def reporthook(block_num, block_size, total_size):
        downloaded = block_num * block_size
        if total_size > 0:
            percent = min(100, downloaded * 100 // total_size)
            mb = downloaded / (1024 * 1024)
            total_mb = total_size / (1024 * 1024)
            sys.stdout.write(f"\r[{percent:3d}%] {mb:.1f} / {total_mb:.1f} MB")
            sys.stdout.flush()

    urllib.request.urlretrieve(url, dest, reporthook)
    print("\nDownload complete.")

def extract_tar(archive: Path, dest: Path):
    print(f"Extracting {archive.name} ...")
    with tarfile.open(archive, "r:gz") as tar:
        # filter="data" blocks path-traversal / unsafe members in the archive
        tar.extractall(path=dest, filter="data")
    print("Extraction done.")

def main():
    print("=" * 60)
    print("llama.cpp CUDA prebuilt for Kaggle dual T4 (SM 7.5)")
    print("=" * 60)

    if ARCHIVE_PATH.exists():
        print(f"Archive already exists: {ARCHIVE_PATH}")
    else:
        download_with_progress(URL, ARCHIVE_PATH)

    # Extract into /kaggle/working/llama.cpp/
    extract_tar(ARCHIVE_PATH, DEST_DIR)

    # Typical structure after extraction: cuda-12.8/ or just the binaries
    print("\nContents:")
    for p in sorted(DEST_DIR.rglob("*"))[:20]:
        print(" ", p.relative_to(DEST_DIR))

    print("\nDone!")
    print(f"Binaries are in: {DEST_DIR}")
    print("\nExample usage (dual T4):")
    print(f"  cd {DEST_DIR}")
    print("  ./llama-cli -m your_model.gguf -ngl 99 --tensor-split 0.5,0.5 -fa on")
    print("  # or")
    print("  ./llama-server -m your_model.gguf -ngl 99 --tensor-split 0.5,0.5 -fa on --host 0.0.0.0 --port 8080")

if __name__ == "__main__":
    main()
