# Kaggle dual-T4 llama.cpp server, direct Cloudflare Quick Tunnel

No Render relay, no frp -- this is the simpler setup: `cloudflared`'s anonymous
Quick Tunnel, straight from the Kaggle notebook.

## Every Kaggle session

Run in order, each in its own cell:

1. `01_download_llamacpp.py` - downloads + extracts the CUDA llama.cpp build to `/kaggle/working/llama.cpp`
2. `02_download_cloudflared.py` - downloads the cloudflared binary to `/kaggle/working/cloudflared`
3. `03_download_model.py` - downloads the GGUF model to `/kaggle/tmp/models` (not `/kaggle/working` - that caps at 20GiB, `/kaggle/tmp` gives ~57GB but does not persist across sessions)
4. `04_launch_server.py` - loads the model across both GPUs, opens the tunnel, prints the base URL + API key

## Default model

`unsloth/Qwen3.8-27B-GGUF` / `Qwen3.8-27B-UD-Q4_K_XL.gguf` (17.6GB) -- Unsloth's
"Dynamic" 4-bit quant. This is a mixed-precision quant tuned to preserve much
more accuracy than a plain/uniform Q4_K_M at the same bit-width, which is
likely why a plain Q4 quant hallucinated more for you earlier.

To swap models, set env vars before running `03_download_model.py`:
```
%env HF_REPO_ID=unsloth/Qwen3.8-27B-GGUF
%env HF_FILENAME=Qwen3.8-27B-Q8_0.gguf
```
If more than one `.gguf` ends up in `/kaggle/tmp/models`, set `MODEL_FILENAME`
explicitly before running `04_launch_server.py` (otherwise it picks whichever
you downloaded most recently):
```
%env MODEL_FILENAME=Qwen3.8-27B-UD-Q4_K_XL.gguf
```

## Speed / context strategy

KV cache (context) always stays on GPU, quantized to `q8_0`. To fit that
alongside the model under limited VRAM, excess weight *layers* spill to
CPU/RAM instead (`-ngl` auto-steps down: 99 -> 80 -> 64 -> ...) rather than
moving the KV cache itself off GPU -- only those layers' compute goes through
CPU, not every token's attention state, so it's far less costly than
RAM-offloaded KV cache. Target context is 64k tokens, auto-falling back
(32768 -> 16384 -> ...) only if even minimal GPU-layer offload can't fit it.

With the smaller 17.6GB quant there should be enough VRAM headroom (weights
~8.8GB/GPU out of 15GB) that full GPU offload (`-ngl 99`) and 64k context
both fit without needing to spill any layers to CPU at all.

## Sampling settings, and the "cleaning cooking washing..." fix

`--temp 0.1 --repeat-penalty 1.1 --repeat-last-n 256`. The earlier version
also added `--presence-penalty 0.3`, which flatly penalizes re-using *any*
recently-seen token regardless of whether it fits -- stacked with
`repeat-penalty` at a near-zero temperature, the model had nowhere sane left
to go and started grabbing random unrelated words just because they were
"unused" (the word-salad you saw on long outputs). `presence-penalty` is
removed here and `repeat-penalty` lowered to 1.1.

Worth knowing: Unsloth's own documented recommended settings for this model
are `--temp 1.0 --top-p 0.95 --top-k 20 --min-p 0.0` -- notably not a low
temperature at all. If loops or degeneration come back even with the lighter
penalties above, raising `--temp` (rather than adding more penalties) is
probably the more reliable fix; very low temperature plus repetition
penalties is an inherently unstable combination.

## What's fixed in these script versions

- `LD_LIBRARY_PATH` is auto-populated from every `.so` found under the llama.cpp folder, plus common system driver paths (fixes both `libllama-server-impl.so` and `libcuda.so.1` "cannot open shared object file" errors)
- `-fa` is passed as `-fa on` (newer llama.cpp requires an explicit value)
- Tunnel URL is extracted with a regex matching `https://...trycloudflare.com` only, so it can't grab the earlier "Requesting new quick Tunnel on trycloudflare.com..." status line by mistake
- Server crash is detected immediately during startup instead of waiting out the full health-check timeout
- A random API key is generated and required (`--api-key`) - the tunnel is a public, unauthenticated URL otherwise
- `01_download_llamacpp.py` extracts its tarball with `filter="data"` to avoid unsafe archive members
- `03_download_model.py` verifies download completeness against the real file size from the Hub API, not a hardcoded number

## Known constraints worth remembering

- `/kaggle/working` = 20GiB hard cap, persists with the session. `/kaggle/tmp` = ~57GB, does not persist.
- Cloudflare Quick Tunnels (`trycloudflare.com`) drop idle HTTP/2 streams after ~60s of no data. Keeping KV cache on GPU and using a smaller/faster quant keeps generation fast enough that this is much less likely to trigger, but a very long prompt's prefill time could still exceed it.
- Running an uncensored/abliterated model on a public, unauthenticated-by-default tunnel is your call, but keep the API key on unless you mean for anyone with the URL to use it.
