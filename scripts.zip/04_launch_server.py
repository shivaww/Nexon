#!/usr/bin/env python3
"""
Find llama.cpp + model, load a DENSE model split across dual T4 GPUs,
KV cache on GPU (spilling weight layers to CPU/RAM as needed), launch a
direct Cloudflare Quick Tunnel. Prints step-by-step status and live
model-loading progress.
"""

import os, sys, subprocess, time, secrets, signal, threading, re
from pathlib import Path
import urllib.request

LLAMA_DIR   = Path("/kaggle/working/llama.cpp")
MODEL_DIR   = Path("/kaggle/tmp/models")
CLOUDFLARED = Path("/kaggle/working/cloudflared")
LOG_FILE    = Path("/kaggle/working/llama-server.log")
PORT        = 8080
API_KEY     = secrets.token_hex(16)
TOTAL_STEPS = 5

URL_RE = re.compile(r"https://[a-zA-Z0-9\-]+\.trycloudflare\.com")

# KV cache (context) always stays on GPU -- fast, no PCIe round-trips per
# token, and no idle gaps that could trip the Quick Tunnel's ~60s timeout.
# To make room for it, excess weight LAYERS spill to CPU/RAM instead
# (--ngl steps down) rather than moving KV cache itself off GPU. 64k is the
# target context; only shrinks if even minimal GPU-layer offload can't fit it.
CONTEXT_CANDIDATES = [65536, 32768, 16384, 8192, 4096]
NGL_CANDIDATES = [99, 80, 64, 48, 32, 24, 16, 8]

OOM_PATTERNS = (
    "out of memory", "cudamalloc failed", "cuda error", "failed to allocate",
    "bad_alloc", "cannot allocate memory",
)

PROGRESS_KEYWORDS = (
    "load_tensors", "offload", "n_ctx", "kv self size",
    "n_gpu_layers", "server is listening",
)

SYSTEM_LIB_DIRS = (
    "/usr/lib/x86_64-linux-gnu",
    "/usr/local/nvidia/lib64",
    "/usr/local/cuda/lib64",
    "/usr/lib/nvidia",
)


def step(n, msg):
    print(f"\n[{n}/{TOTAL_STEPS}] {msg}")


def find_binary(name: str) -> Path:
    matches = list(LLAMA_DIR.rglob(name))
    if not matches:
        sys.exit(f"ERROR: {name} not found under {LLAMA_DIR}")
    return matches[0]


def find_model() -> Path:
    override = os.environ.get("MODEL_FILENAME")
    if override:
        p = MODEL_DIR / override
        if not p.exists():
            sys.exit(f"ERROR: {p} not found")
        return p
    matches = list(MODEL_DIR.rglob("*.gguf"))
    if not matches:
        sys.exit(f"ERROR: no .gguf found under {MODEL_DIR}")
    # most recently downloaded, not largest -- avoids silently picking an old
    # bigger quant when you've since downloaded a smaller one to switch models
    return max(matches, key=lambda p: p.stat().st_mtime)


def lib_dirs_for(binary: Path) -> str:
    dirs = {p.parent for p in LLAMA_DIR.rglob("*.so*")}
    dirs.add(binary.parent)
    for d in SYSTEM_LIB_DIRS:
        if Path(d).exists():
            dirs.add(Path(d))
    return ":".join(str(d) for d in dirs)


def tail_progress(log_path: Path, stop_event: threading.Event):
    while not log_path.exists() and not stop_event.is_set():
        time.sleep(0.5)
    with open(log_path) as f:
        while not stop_event.is_set():
            line = f.readline()
            if not line:
                time.sleep(0.3)
                continue
            if any(k in line.lower() for k in PROGRESS_KEYWORDS):
                print(f"    {line.strip()}")


def log_has_oom(log_path: Path) -> bool:
    if not log_path.exists():
        return False
    text = log_path.read_text(errors="ignore").lower()
    return any(p in text for p in OOM_PATTERNS)


def wait_for_ready(proc: subprocess.Popen, port: int, timeout: int = 420):
    """Returns 'ready', 'crashed', or 'timeout'."""
    url = f"http://127.0.0.1:{port}/health"
    start = time.time()
    while time.time() - start < timeout:
        if proc.poll() is not None:
            return "crashed"
        try:
            urllib.request.urlopen(url, timeout=3)
            return "ready"
        except Exception:
            time.sleep(2)
    return "timeout"


def build_server_cmd(server_bin, model_path, ctx, ngl):
    return [
        str(server_bin),
        "-m", str(model_path),
        "-ngl", str(ngl),            # weight layers offloaded to GPU; rest run on CPU/RAM
        "--tensor-split", "1,1",     # equal split across the two T4s
        "--cache-type-k", "q8_0",    # quantized KV cache -> more context fits in leftover VRAM
        "--cache-type-v", "q8_0",
        "-c", str(ctx),
        "-fa", "on",                 # flash attention (required for KV cache quantization)
        "--temp", "0.1",
        "--repeat-penalty", "1.1",   # mild -- 1.15 combined with presence-penalty was pushing
        "--repeat-last-n", "256",    # the model into unrelated-word "word salad" on long outputs
        "--host", "0.0.0.0",
        "--port", str(PORT),
        "--api-key", API_KEY,
    ]


def start_server(server_bin, model_path, env, ctx, ngl):
    log = open(LOG_FILE, "w", buffering=1)
    cmd = build_server_cmd(server_bin, model_path, ctx, ngl)
    proc = subprocess.Popen(["stdbuf", "-oL", "-eL", *cmd], stdout=log, stderr=subprocess.STDOUT, env=env)
    stop_event = threading.Event()
    threading.Thread(target=tail_progress, args=(LOG_FILE, stop_event), daemon=True).start()
    return proc, stop_event


def load_model(server_bin, model_path, env):
    for ctx in CONTEXT_CANDIDATES:
        for ngl in NGL_CANDIDATES:
            print(f"    attempting context={ctx}, gpu_layers={ngl}...")
            proc, stop_event = start_server(server_bin, model_path, env, ctx, ngl)
            result = wait_for_ready(proc, PORT)
            stop_event.set()

            if result == "ready":
                print(f"    model loaded, context={ctx}, gpu_layers={ngl}, server listening on port {PORT}")
                return proc, ctx, ngl

            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()

            if result == "crashed" and log_has_oom(LOG_FILE):
                print(f"    did not fit in VRAM, offloading fewer layers to GPU...")
                continue
            elif result == "crashed":
                sys.exit(f"ERROR: server crashed for a non-OOM reason. Check {LOG_FILE}")
            else:
                sys.exit(f"ERROR: server did not become healthy within timeout (ctx={ctx}, ngl={ngl}). Check {LOG_FILE}")

        print(f"    context {ctx} did not fit even with minimal GPU layers, trying smaller context...")

    sys.exit(f"ERROR: model did not fit even at smallest context/ngl combination. Check {LOG_FILE}")


def main():
    step(1, "Locating llama.cpp binary...")
    server_bin = find_binary("llama-server")
    print(f"    found: {server_bin}")

    step(2, "Locating model file...")
    model_path = find_model()
    size_gb = model_path.stat().st_size / 1024**3
    print(f"    found: {model_path} ({size_gb:.1f} GB)")

    step(3, "Locating cloudflared binary...")
    if not CLOUDFLARED.exists():
        sys.exit(f"ERROR: cloudflared not found at {CLOUDFLARED}")
    print(f"    found: {CLOUDFLARED}")

    step(4, "Loading model into GPUs (dual T4, tensor-split 1:1, KV cache on GPU, spilling layers to CPU as needed)...")
    env = os.environ.copy()
    lib_path = lib_dirs_for(server_bin)
    env["LD_LIBRARY_PATH"] = lib_path + ":" + env.get("LD_LIBRARY_PATH", "")

    server_proc, ctx_used, ngl_used = load_model(server_bin, model_path, env)

    step(5, "Starting cloudflared tunnel...")
    tunnel_proc = subprocess.Popen(
        [str(CLOUDFLARED), "tunnel", "--url", f"http://localhost:{PORT}"],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1,
    )

    def shutdown(*_):
        print("\nShutting down...")
        tunnel_proc.terminate()
        server_proc.terminate()
        sys.exit(0)

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    public_url = None
    for line in tunnel_proc.stdout:
        match = URL_RE.search(line)
        if match:
            public_url = match.group(0)
            break

    if not public_url:
        sys.exit("ERROR: tunnel did not return a public URL. Check cloudflared output.")

    print()
    print("=" * 60)
    print("READY")
    print("=" * 60)
    print(f"Base URL   : {public_url}/v1")
    print(f"API key    : {API_KEY}")
    print(f"Context    : {ctx_used} tokens")
    print(f"GPU layers : {ngl_used}")
    print("=" * 60)
    print()

    server_proc.wait()


if __name__ == "__main__":
    main()
