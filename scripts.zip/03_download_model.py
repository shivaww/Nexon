import os

# Must be set before importing huggingface_hub
os.environ["HF_HUB_DISABLE_XET"] = "1"          # avoids the 70-99% stuck-download issue
os.environ["HF_HUB_DOWNLOAD_TIMEOUT"] = "300"
os.environ["HF_HUB_ETAG_TIMEOUT"] = "60"
os.environ["HF_HOME"] = "/kaggle/tmp/hf_cache"

from huggingface_hub import hf_hub_download, HfApi, login
from pathlib import Path
import time

# Override these via env vars if you swap models, e.g.:
#   %env HF_REPO_ID=unsloth/Qwen3.8-27B-GGUF
#   %env HF_FILENAME=Qwen3.8-27B-UD-Q4_K_XL.gguf
# Default is Unsloth's "Dynamic" 4-bit quant (UD-Q4_K_XL) -- their mixed-precision
# quant that preserves noticeably more accuracy than a plain Q4_K_M at the same
# bit-width. Use plain Q4_K_M/Q4_0 only if you specifically want the smaller
# uniform quant instead.
REPO_ID  = os.environ.get("HF_REPO_ID", "unsloth/Qwen3.8-27B-GGUF")
FILENAME = os.environ.get("HF_FILENAME", "Qwen3.8-27B-UD-Q4_K_XL.gguf")

LOCAL_DIR = Path("/kaggle/tmp/models")   # /kaggle/working caps at 20GiB; use scratch space instead
LOCAL_DIR.mkdir(parents=True, exist_ok=True)

# Optional: only needed for gated repos.
hf_token = os.environ.get("HF_TOKEN")
if hf_token:
    login(token=hf_token)
    print("Logged in with HF_TOKEN")

# Look up the real file size from the Hub so the completeness check works
# for whatever REPO_ID/FILENAME you point it at, not just one hardcoded model.
expected_bytes = None
try:
    info = HfApi().model_info(REPO_ID, files_metadata=True, token=hf_token)
    match = next((s for s in info.siblings if s.rfilename == FILENAME), None)
    if match:
        expected_bytes = match.size
        print(f"Expected size (from Hub): {expected_bytes / 1024**3:.2f} GB")
    else:
        print(f"Warning: {FILENAME} not found in {REPO_ID} file list. Check the name.")
except Exception as e:
    print(f"Could not fetch expected size from Hub ({e}); skipping size check.")

print(f"\nDownloading {REPO_ID}/{FILENAME} -> {LOCAL_DIR}")

for attempt in range(1, 6):
    try:
        print(f"\n--- Attempt {attempt}/5 ---")
        path = hf_hub_download(
            repo_id=REPO_ID,
            filename=FILENAME,
            local_dir=str(LOCAL_DIR),
            token=hf_token,
        )

        actual_bytes = os.path.getsize(path)
        print(f"Downloaded -> {path}")
        print(f"Size: {actual_bytes / 1024**3:.2f} GB")

        if expected_bytes is None or actual_bytes >= expected_bytes * 0.99:
            print("Download complete and size looks correct.")
            break
        else:
            print("File smaller than expected, retrying...")
            time.sleep(8)

    except Exception as e:
        print(f"Error: {e}")
        time.sleep(10 * attempt)
else:
    raise SystemExit("Failed after 5 attempts.")
